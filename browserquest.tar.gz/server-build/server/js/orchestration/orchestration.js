var cls = require('../lib/class'),
    events = require('events');

/**
  The base class orchestration class is designed to allow for a plugable orchestrations
  to handle certain functions
 **/

module.exports = Orchestration = cls.Class.extend({
    
});