var cls = require("../lib/class");

module.exports = Message = cls.Class.extend({
});